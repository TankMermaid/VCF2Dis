
////////////////////////swimming in the sea & flying in the sky //////////////////


/*
 * DataClass.h
 *
 *  Created on: 2011-11-21
 *      Author: hewm@genomics.org.cn
 */

#ifndef DataClass_H_
#define DataClass_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;


///////////////// q_seq  for site ////////


class In3str1v {
	public:
		string InStr1 ;
		string InStr2 ;
		string InStr3 ;
		bool  TF ;
		In3str1v()
		{
			InStr1="";
			InStr2="";
			InStr3="";
			TF=false ;
		}
};



	////////swimming in the sky and flying in the sea *///////////





#endif /* DataClass_H_ */

//////////////// swimming in the sky and flying in the sea ////////////////
